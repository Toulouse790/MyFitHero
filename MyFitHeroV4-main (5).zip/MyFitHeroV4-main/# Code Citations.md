# Code Citations

## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
├
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
├
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
├─────────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
├─────────────────────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
├─────────────────────────────┬───────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
├─────────────────────────────┬───────────────────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
├─────────────────────────────┬────────────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
├─────────────────────────────┬────────────────────────────────
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ 
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ 
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐ │ ┌
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐ │ ┌
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐ │ ┌───
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐ │ ┌───
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐ │ ┌─────────────────────────────
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐ │ ┌─────────────────────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─────────────────────────┘
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
│
│ └─────────────────────────┘ │ └───────────────
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─────────────────────────┘ │ └───────────────
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────────
```


## License: inconnu
https://github.com/netkiller/netkiller.github.io/blob/83c759f82329f743b78fdc3a09cef0d6e79cf3ed/www/php.zend.html

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────────
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
├─────────────────────────────┼───────────────────────────────────
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐ │ ┌───────
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐ │ ┌───────
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐ │ ┌─────────────────────────────
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐ │ ┌─────────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
────────
```


## License: inconnu
https://github.com/iamgreaser/sackit/blob/dc29bbba97e5fb62be8ce8126cbc028726bfc7d8/playroutine.c

```
────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
────────────────────────┘ │
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
────────────────────────┘ │
```


## License: inconnu
https://github.com/iamgreaser/sackit/blob/dc29bbba97e5fb62be8ce8126cbc028726bfc7d8/playroutine.c

```
────────────────────────┘ │
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
────────────────────────┘ │                                   │
├─────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
────────────────────────┘ │                                   │
├─────
```


## License: inconnu
https://github.com/iamgreaser/sackit/blob/dc29bbba97e5fb62be8ce8126cbc028726bfc7d8/playroutine.c

```
────────────────────────┘ │                                   │
├─────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
────────────────────────┘ │                                   │
├─────────────────────────────┼
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
────────────────────────┘ │                                   │
├─────────────────────────────┼
```


## License: inconnu
https://github.com/iamgreaser/sackit/blob/dc29bbba97e5fb62be8ce8126cbc028726bfc7d8/playroutine.c

```
────────────────────────┘ │                                   │
├─────────────────────────────┼
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
────────────────────────┘ │                                   │
├─────────────────────────────┼───────────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
────────────────────────┘ │                                   │
├─────────────────────────────┼───────────────────────────────
```


## License: inconnu
https://github.com/iamgreaser/sackit/blob/dc29bbba97e5fb62be8ce8126cbc028726bfc7d8/playroutine.c

```
────────────────────────┘ │                                   │
├─────────────────────────────┼───────────────────────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
────────────────────────┘ │                                   │
├─────────────────────────────┼───────────────────────────────────
```


## License: LGPL-3.0
https://github.com/c00kiemon5ter/zipf/blob/4de43489a642ba3d8f86cd13fc040b49b0a14715/data/dumpfiles/8429.raw

```
────────────────────────┘ │                                   │
├─────────────────────────────┼───────────────────────────────────
```


## License: inconnu
https://github.com/iamgreaser/sackit/blob/dc29bbba97e5fb62be8ce8126cbc028726bfc7d8/playroutine.c

```
────────────────────────┘ │                                   │
├─────────────────────────────┼───────────────────────────────────
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐ │ ┌───────
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐ │ ┌───────
```


## License: Apache-2.0
https://github.com/gradle/gradle/blob/3d4c0e819123c79c2761b27f47dcd77e66bd92b8/subprojects/docs/README.md

```
│ ┌─────────────────────────┐ │ ┌─────────────────────────────
```


## License: MIT
https://github.com/mkbaldwin/notes-public/blob/7343948bfe725752bcd967af29c99cf4df07e551/pluralsight/aws-ccp_3_intro-to-security-architecture.md

```
│ ┌─────────────────────────┐ │ ┌─────────────────────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─
```


## License: MIT
https://github.com/jongracecox/anybadge/blob/cc5a757663a754ff3b32f510bcdeccf995fbfcae/anybadge/badge.py

```
│
│ └─
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘
```


## License: MIT
https://github.com/jongracecox/anybadge/blob/cc5a757663a754ff3b32f510bcdeccf995fbfcae/anybadge/badge.py

```
│
│ └─────────────────────────┘
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────
```


## License: MIT
https://github.com/jongracecox/anybadge/blob/cc5a757663a754ff3b32f510bcdeccf995fbfcae/anybadge/badge.py

```
│
│ └─────────────────────────┘ │ └───────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: MIT
https://github.com/jongracecox/anybadge/blob/cc5a757663a754ff3b32f510bcdeccf995fbfcae/anybadge/badge.py

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└
```


## License: MIT
https://github.com/jongracecox/anybadge/blob/cc5a757663a754ff3b32f510bcdeccf995fbfcae/anybadge/badge.py

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────
```


## License: MIT
https://github.com/jongracecox/anybadge/blob/cc5a757663a754ff3b32f510bcdeccf995fbfcae/anybadge/badge.py

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────┴───────────────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────┴───────────────────────
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────┴───────────────────────
```


## License: MIT
https://github.com/jongracecox/anybadge/blob/cc5a757663a754ff3b32f510bcdeccf995fbfcae/anybadge/badge.py

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────┴───────────────────────
```


## License: inconnu
https://github.com/astro/ruby-feed-parser-benchmark/blob/f9aed5a7198f962f981d7fcdc36191613dce0576/feeds/feed-429613035.atom10

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────┴───────────────────────────────────
```


## License: Apache-2.0
https://github.com/membase/ep-engine/blob/5cf47c058c3cc73d4fb90f7d295530f395808526/docs/collections.md

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────┴───────────────────────────────────
```


## License: MIT
https://github.com/goblint/analyzer/blob/3abe9653caa77bad9348ec5443b0af494700d379/tests/regression/cfg/foo.t/run.t

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────┴───────────────────────────────────
```


## License: MIT
https://github.com/jongracecox/anybadge/blob/cc5a757663a754ff3b32f510bcdeccf995fbfcae/anybadge/badge.py

```
│
│ └─────────────────────────┘ │ └───────────────────────────────┘ │
└─────────────────────────────┴───────────────────────────────────
```

