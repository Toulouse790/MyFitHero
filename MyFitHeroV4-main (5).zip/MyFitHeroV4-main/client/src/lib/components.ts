// ====================================================================
// MyFitHero - Composants Utilitaires et Configuration PWA
// ====================================================================

// Re-export des composants depuis index.tsx pour éviter les warnings Fast Refresh
export { pwaConfig, AppErrorBoundary, AppLoadingSpinner, AuthGuard } from '../pages/index';
