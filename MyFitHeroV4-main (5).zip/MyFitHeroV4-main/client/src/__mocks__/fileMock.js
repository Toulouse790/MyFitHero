// Mock pour les fichiers statiques (images, etc.)
module.exports = 'test-file-stub';
