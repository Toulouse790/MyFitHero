import { ReactNode } from 'react';

export type ToastActionElement = ReactNode;
