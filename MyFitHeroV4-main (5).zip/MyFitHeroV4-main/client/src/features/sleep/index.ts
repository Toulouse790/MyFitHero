// Export principal du module sleep
// export * from './types/index';
// export * from './services/sleep.service';
// export * from './hooks/useSleep';

// Exports des composants (à implémenter)
// export * from './components';
// export * from './pages';

// Placeholder pour éviter les erreurs d'import
export const SleepModule = {
  name: 'sleep',
  status: 'planned',
  description: 'Module sleep - À implémenter',
};
