// Export principal du module social
// export * from './types/index';
// export * from './services/social.service';
// export * from './hooks/useSocial';

// Exports des composants (à implémenter)
// export * from './components';
// export * from './pages';

// Placeholder pour éviter les erreurs d'import
export const SocialModule = {
  name: 'social',
  status: 'planned',
  description: 'Module social - À implémenter',
};
