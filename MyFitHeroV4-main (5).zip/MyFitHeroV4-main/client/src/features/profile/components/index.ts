// Export des composants de la feature profile
export { default as UniformHeader } from './UniformHeader';
export { default as AvatarUpload } from './AvatarUpload';
export { default as UserProfileTabs } from './UserProfileTabs';
