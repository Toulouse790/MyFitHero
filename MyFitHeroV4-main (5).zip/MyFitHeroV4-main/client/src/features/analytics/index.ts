// Export principal du module analytics
// export * from './types/index';
// export * from './services/analytics.service';
// export * from './hooks/useAnalytics';

// Exports des composants (à implémenter)
// export * from './components';
// export * from './pages';

// Placeholder pour éviter les erreurs d'import
export const AnalyticsModule = {
  name: 'analytics',
  status: 'planned',
  description: 'Module analytics - À implémenter',
};
