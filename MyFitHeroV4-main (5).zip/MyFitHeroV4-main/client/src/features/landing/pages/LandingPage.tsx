import React from 'react';

const LandingPage = () => {
  return (
    <div>
      <h1>Landing Page</h1>
    </div>
  );
};

export default LandingPage;
