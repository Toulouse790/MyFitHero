// Export des types de la feature landing
export * from './index';
