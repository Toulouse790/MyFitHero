// Export des types de la feature admin
export * from './index';
