// Export principal du module admin
// export * from './types/index';
// export * from './services/admin.service';
// export * from './hooks/useAdmin';

// Exports des composants (à implémenter)
// export * from './components';
// export * from './pages';

// Placeholder pour éviter les erreurs d'import
export const AdminModule = {
  name: 'admin',
  status: 'planned',
  description: 'Module admin - À implémenter',
};
