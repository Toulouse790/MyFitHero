// client/src/features/admin/components/index.ts
export { AdminDashboard } from './AdminDashboard';
