// Export principal du module hydration
// export * from './types/index';
// export * from './services/hydration.service';
// export * from './hooks/useHydration';

// Exports des composants (à implémenter)
// export * from './components';
// export * from './pages';

// Placeholder pour éviter les erreurs d'import
export const HydrationModule = {
  name: 'hydration',
  status: 'planned',
  description: 'Module hydration - À implémenter',
};
