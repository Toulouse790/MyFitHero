// Export des types de la feature nutrition
export * from './index';
