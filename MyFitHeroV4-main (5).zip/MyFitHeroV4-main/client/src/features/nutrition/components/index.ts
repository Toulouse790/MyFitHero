// Export des composants de la feature nutrition
export { default as PersonalInfoForm } from './PersonalInfoForm';
export { default as ProtectedRoute } from './ProtectedRoute';
