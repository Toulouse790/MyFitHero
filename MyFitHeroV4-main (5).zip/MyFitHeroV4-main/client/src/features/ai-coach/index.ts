// Export principal du module ai-coach
// export * from './types/index';
// export * from './services/ai-coach.service';
// export * from './hooks/useAi-coach';

// Exports des composants (à implémenter)
// export * from './components';
// export * from './pages';

// Placeholder pour éviter les erreurs d'import
export const AiCoachModule = {
  name: 'ai-coach',
  status: 'planned',
  description: 'Module ai-coach - À implémenter',
};
