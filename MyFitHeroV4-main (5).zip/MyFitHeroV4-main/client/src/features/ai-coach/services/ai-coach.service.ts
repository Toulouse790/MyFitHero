export class AICoachService {
  /**
   * Récupère une session de coaching
   */
  static async getCoachingSession(_userId: string, _topic: string) {
    // Implementation à venir
    return null;
  }

  /**
   * Soumet une question
   */
  static async submitQuestion(_question: string, _context: unknown) {
    // Implementation à venir
    return null;
  }

  /**
   * Récupère un plan personnalisé
   */
  static async getPersonalizedPlan(_profile: unknown) {
    // Implementation à venir
    return null;
  }

  /**
   * Analyse les progrès
   */
  static async analyzeProgress(_data: unknown) {
    // Implementation à venir
    return null;
  }
}
