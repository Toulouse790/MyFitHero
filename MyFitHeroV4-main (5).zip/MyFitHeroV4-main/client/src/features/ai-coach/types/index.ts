// Export des types de la feature ai-coach
export * from './index';
