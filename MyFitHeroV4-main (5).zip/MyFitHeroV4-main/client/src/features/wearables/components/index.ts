// Export des composants de la feature wearables
export { default as WearableNotificationCenter } from './WearableNotificationCenter';
