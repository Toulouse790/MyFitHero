// Export des types de la feature wearables
export * from './index';
