// Export principal du module wearables
// export * from './types/index';
// export * from './services/wearables.service';
// export * from './hooks/useWearables';

// Exports des composants (à implémenter)
// export * from './components';
// export * from './pages';

// Placeholder pour éviter les erreurs d'import
export const WearablesModule = {
  name: 'wearables',
  status: 'planned',
  description: 'Module wearables - À implémenter',
};
