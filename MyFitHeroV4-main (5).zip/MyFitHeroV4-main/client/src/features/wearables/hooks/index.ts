// Export des hooks de la feature wearables
export * from './index';
export * from './useWearables';
export * from './useWearableSync';
