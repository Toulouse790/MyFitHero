# Plan de content - MyFitHero V4

Voici intelligente avec routing d’AI assistants (OpenAI, Replicate), Supabase, et frontend React via Vercel.

Structure proposée des fonctionnalités : /src/components, /src/pages, /src/lib /src/agents 

## Objectifs 

- Regrouper toutes les intell data et composants autour d'un utilisateur

- Automatiser tous les appels de gestion via Assessants

- Effectuer des suivis customisés sur la nouvelle BD Supabase

Tout ce projet est préparé pour un d'éploiement via Vercel.